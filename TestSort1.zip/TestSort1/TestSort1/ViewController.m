//
//  ViewController.m
//  TestSort1
//
//  Created by Arthur on 2020/4/13.
//  Copyright © 2020 Arthur. All rights reserved.
//

#import "ViewController.h"
#import "ViewB.h"
#import "ViewD.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //    NSMutableArray *arr = [NSMutableArray array];
    //    [arr addObject:@"test"];
    //    [arr addObject:@"number"];
    //    NSLog(@"%@", arr[0]);
        
    Class commonClass = [self commonClass1:[ViewB class] andClass:[ViewD class]];
    NSLog(@"%@",commonClass);
}
// 获取所有父类
- (NSArray *)superClasses:(Class)class {
    if (class == nil) {
        return @[];
    }
    NSMutableArray *result = [NSMutableArray array];
    while (class != nil) {
        [result addObject:class];
        class = [class superclass];
    }
    return [result copy];
}

- (Class)commonClass1:(Class)classA andClass:(Class)classB {
    NSArray *arr1 = [self superClasses:classA];
    NSArray *arr2 = [self superClasses:classB];
    NSInteger count = arr1.count < arr2.count ? arr1.count : arr2.count;
    Class resultClass;
    for (NSUInteger i = 0; i < arr1.count; ++i) {
        Class classA = arr1[arr1.count - i -1];
        Class classB = arr2[arr2.count - i -1];
        if(classA == classB){
            resultClass = classA;
        }else{
            break;
        }
    }
    return resultClass;
}
@end
