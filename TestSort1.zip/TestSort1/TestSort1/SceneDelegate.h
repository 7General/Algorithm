//
//  SceneDelegate.h
//  TestSort1
//
//  Created by Arthur on 2020/4/13.
//  Copyright © 2020 Arthur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

